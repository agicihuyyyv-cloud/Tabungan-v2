import { useEffect, useState } from "react";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription, DrawerFooter } from "@/components/ui/drawer.jsx";
import { Button } from "@/components/ui/button.jsx";
import { Input } from "@/components/ui/input.jsx";
import { Field, FieldError, FieldGroup, FieldLabel } from "@/components/ui/field.jsx";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group.jsx";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select.jsx";
import { goalBalance, rp, num } from "./lib/store.js";

const CHIPS = [10000, 50000, 100000, 500000];

export default function TxDrawer({ open, onOpenChange, preset, goals, tx, onSave }) {
  const [type, setType] = useState("in");
  const [goalId, setGoalId] = useState("");
  const [amount, setAmount] = useState(0);
  const [note, setNote] = useState("");
  const [tried, setTried] = useState(false);

  useEffect(() => {
    if (open) {
      setType(preset.type);
      setGoalId(preset.goalId ?? goals[0]?.id ?? "");
      setAmount(0);
      setNote("");
      setTried(false);
    }
  }, [open]);

  const bal = goalBalance(tx, goalId);
  const err = !goalId ? "Bikin celengan dulu." : amount <= 0 ? "Isi nominalnya." : type === "out" && amount > bal ? `Saldo celengan cuma ${rp(bal)}.` : null;

  const submit = () => {
    setTried(true);
    if (err) return;
    onSave({ type, goalId, amount, note: note.trim() });
    onOpenChange(false);
  };

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="mx-auto max-w-[430px]">
        <DrawerHeader>
          <DrawerTitle className="font-display text-xl font-extrabold">{type === "in" ? "Setor tabungan" : "Tarik tabungan"}</DrawerTitle>
          <DrawerDescription className="sr-only">Isi detailnya lalu simpan.</DrawerDescription>
        </DrawerHeader>
        <div className="px-4">
          <FieldGroup>
            <ToggleGroup type="single" variant="outline" value={type} onValueChange={(v) => v && setType(v)} className="w-full">
              <ToggleGroupItem value="in" className="flex-1">Setor</ToggleGroupItem>
              <ToggleGroupItem value="out" className="flex-1">Tarik</ToggleGroupItem>
            </ToggleGroup>
            <Field data-invalid={tried && err ? true : undefined}>
              <FieldLabel htmlFor="amt">Nominal</FieldLabel>
              <div className="flex items-baseline gap-2 border-b-2 border-primary pb-1">
                <span className="font-display text-2xl font-extrabold text-muted-foreground">Rp</span>
                <input
                  id="amt"
                  inputMode="numeric"
                  autoComplete="off"
                  placeholder="0"
                  value={amount ? num(amount) : ""}
                  onChange={(e) => setAmount(Number(e.target.value.replace(/\D/g, "").slice(0, 12)) || 0)}
                  onKeyDown={(e) => e.key === "Enter" && submit()}
                  aria-invalid={tried && err ? true : undefined}
                  className="w-full bg-transparent font-display text-4xl font-extrabold tracking-tight outline-none placeholder:text-muted-foreground/50"
                />
              </div>
              <div className="mt-2 flex flex-wrap gap-2">
                {CHIPS.map((c) => (
                  <Button key={c} type="button" size="sm" variant="secondary" onClick={() => setAmount((a) => a + c)}>
                    +{c >= 1000 ? `${c / 1000}rb` : c}
                  </Button>
                ))}
              </div>
              {tried && err && <FieldError>{err}</FieldError>}
            </Field>
            <Field>
              <FieldLabel htmlFor="goal">Celengan</FieldLabel>
              <NativeSelect id="goal" value={goalId} onChange={(e) => setGoalId(e.target.value)}>
                {goals.map((g) => (
                  <NativeSelectOption key={g.id} value={g.id}>{g.name} · {rp(goalBalance(tx, g.id))}</NativeSelectOption>
                ))}
              </NativeSelect>
            </Field>
            <Field>
              <FieldLabel htmlFor="note">Catatan (opsional)</FieldLabel>
              <Input id="note" placeholder="mis. sisa uang jajan" value={note} onChange={(e) => setNote(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} />
            </Field>
          </FieldGroup>
        </div>
        <DrawerFooter>
          <Button type="button" size="lg" className="h-12 text-base font-bold" onClick={submit}>
            {type === "in" ? "Masukin ke celengan" : "Tarik sekarang"}
          </Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

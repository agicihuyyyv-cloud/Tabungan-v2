import { useMemo, useState } from "react";
import { X } from "lucide-react";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group.jsx";
import { cn } from "@/lib/utils";
import { withRunning, num, shortDate } from "./lib/store.js";

export default function Passbook({ tx, goals, limit, printedId, filterable, onRemove }) {
  const [filter, setFilter] = useState("all");
  const rows = useMemo(() => {
    let r = withRunning(filter === "all" ? tx : tx.filter((t) => t.goalId === filter));
    r = r.reverse();
    return limit ? r.slice(0, limit) : r;
  }, [tx, filter, limit]);
  const name = (id) => goals.find((g) => g.id === id)?.name ?? "-";

  return (
    <div className="mx-4 mt-3">
      {filterable && goals.length > 1 && (
        <ToggleGroup type="single" variant="outline" value={filter} onValueChange={(v) => v && setFilter(v)} className="mb-3 flex w-full justify-start overflow-x-auto">
          <ToggleGroupItem value="all">Semua</ToggleGroupItem>
          {goals.map((g) => <ToggleGroupItem key={g.id} value={g.id}>{g.name}</ToggleGroupItem>)}
        </ToggleGroup>
      )}
      <div className="guilloche overflow-hidden rounded-[16px] border">
        <div className="grid grid-cols-[3.2rem_1fr_auto] gap-x-3 border-b bg-page/80 px-4 py-2 font-mono text-sm font-semibold uppercase tracking-wider text-stamp">
          <span>Tgl</span><span>Keterangan</span><span className="text-right">Mutasi / Saldo</span>
        </div>
        <div className="ledger-lines">
          {rows.map((t) => (
            <div key={t.id} className={cn("group grid h-14 grid-cols-[3.2rem_1fr_auto] items-center gap-x-3 px-4 font-mono text-sm", t.id === printedId && "print-row")}>
              <span className="text-muted-foreground">{shortDate(t.date)}</span>
              <span className="min-w-0">
                <span className="block truncate font-semibold uppercase">{t.type === "in" ? "SETOR" : "TARIK"} {name(t.goalId)}</span>
                {t.note && <span className="block truncate text-muted-foreground">{t.note}</span>}
              </span>
              <span className="flex items-center gap-2">
                <span className="text-right">
                  <span className={cn("block font-semibold tabular-nums", t.type === "in" ? "text-credit" : "text-debit")}>
                    {t.type === "in" ? "+" : "−"}{num(t.amount)}
                  </span>
                  <span className="block tabular-nums text-muted-foreground">{num(t.saldo)}</span>
                </span>
                {onRemove && (
                  <button type="button" aria-label="Hapus mutasi" onClick={() => onRemove(t.id)} className="rounded p-1 text-muted-foreground opacity-40 hover:text-debit hover:opacity-100">
                    <X className="h-4 w-4" />
                  </button>
                )}
              </span>
            </div>
          ))}
          {rows.length === 0 && <p className="px-4 py-10 text-center font-sans text-muted-foreground">Belum ada mutasi. Setor pertama kamu, yuk.</p>}
        </div>
      </div>
    </div>
  );
}

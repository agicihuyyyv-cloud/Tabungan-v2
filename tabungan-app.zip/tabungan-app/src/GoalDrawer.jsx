import { useEffect, useState } from "react";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription, DrawerFooter } from "@/components/ui/drawer.jsx";
import { Button } from "@/components/ui/button.jsx";
import { Input } from "@/components/ui/input.jsx";
import { Field, FieldError, FieldGroup, FieldLabel } from "@/components/ui/field.jsx";
import { num } from "./lib/store.js";

export default function GoalDrawer({ open, onOpenChange, onSave }) {
  const [name, setName] = useState("");
  const [target, setTarget] = useState(0);
  const [tried, setTried] = useState(false);
  useEffect(() => { if (open) { setName(""); setTarget(0); setTried(false); } }, [open]);
  const nameErr = !name.trim();
  const targetErr = target <= 0;
  const submit = () => {
    setTried(true);
    if (nameErr || targetErr) return;
    onSave({ name: name.trim(), target });
    onOpenChange(false);
  };
  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="mx-auto max-w-[430px]">
        <DrawerHeader>
          <DrawerTitle className="font-display text-xl font-extrabold">Celengan baru</DrawerTitle>
          <DrawerDescription className="sr-only">Isi detailnya lalu simpan.</DrawerDescription>
        </DrawerHeader>
        <div className="px-4">
          <FieldGroup>
            <Field data-invalid={tried && nameErr ? true : undefined}>
              <FieldLabel htmlFor="gname">Nabung buat apa?</FieldLabel>
              <Input id="gname" placeholder="mis. Laptop kuliah" value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} aria-invalid={tried && nameErr ? true : undefined} />
              {tried && nameErr && <FieldError>Kasih nama dulu.</FieldError>}
            </Field>
            <Field data-invalid={tried && targetErr ? true : undefined}>
              <FieldLabel htmlFor="gtarget">Target (Rp)</FieldLabel>
              <Input id="gtarget" inputMode="numeric" placeholder="0" value={target ? num(target) : ""} onChange={(e) => setTarget(Number(e.target.value.replace(/\D/g, "").slice(0, 12)) || 0)} onKeyDown={(e) => e.key === "Enter" && submit()} aria-invalid={tried && targetErr ? true : undefined} />
              {tried && targetErr && <FieldError>Isi targetnya.</FieldError>}
            </Field>
          </FieldGroup>
        </div>
        <DrawerFooter>
          <Button type="button" size="lg" className="h-12 text-base font-bold" onClick={submit}>Bikin celengan</Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

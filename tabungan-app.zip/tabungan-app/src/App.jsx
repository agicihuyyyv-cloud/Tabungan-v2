// Tabungan: aplikasi tabungan bergaya buku tabungan bank.
import { useMemo, useState } from "react";
import { Home, BookOpen, Target, Plus, Minus, MoreHorizontal, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner.jsx";
import { Button } from "@/components/ui/button.jsx";
import { DropdownMenu, DropdownMenuContent, DropdownMenuGroup, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu.jsx";
import { cn } from "@/lib/utils";
import icon from "./assets/icon.webp";
import { useStore, rp, goalBalance } from "./lib/store.js";
import TxDrawer from "./TxDrawer.jsx";
import GoalDrawer from "./GoalDrawer.jsx";
import Passbook from "./Passbook.jsx";
import GoalList from "./GoalList.jsx";

function Glint() {
  return (
    <svg className="glint h-8 w-8 text-gilt" viewBox="0 0 32 32" fill="none" aria-hidden>
      <line x1="10" y1="16" x2="14" y2="6" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <line x1="17" y1="20" x2="27" y2="14" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <line x1="4" y1="22" x2="5" y2="21" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export default function App() {
  const store = useStore();
  const { data } = store;
  const [tab, setTab] = useState("beranda");
  const [txOpen, setTxOpen] = useState(false);
  const [txPreset, setTxPreset] = useState({ type: "in", goalId: null });
  const [goalOpen, setGoalOpen] = useState(false);
  const [printedId, setPrintedId] = useState(null);
  const [bump, setBump] = useState(0);

  const total = useMemo(() => data.tx.reduce((a, t) => a + (t.type === "in" ? t.amount : -t.amount), 0), [data.tx]);
  const totalTarget = data.goals.reduce((a, g) => a + g.target, 0);

  const monthIn = useMemo(() => {
    const now = new Date();
    return data.tx
      .filter((t) => t.type === "in" && new Date(t.date).getMonth() === now.getMonth() && new Date(t.date).getFullYear() === now.getFullYear())
      .reduce((a, t) => a + t.amount, 0);
  }, [data.tx]);

  const openTx = (type, goalId = null) => {
    setTxPreset({ type, goalId });
    setTxOpen(true);
  };

  const saveTx = (tx) => {
    const id = store.addTx(tx);
    setPrintedId(id);
    setBump((b) => b + 1);
    const g = data.goals.find((x) => x.id === tx.goalId);
    toast.success(tx.type === "in" ? `${rp(tx.amount)} masuk ke ${g?.name}` : `${rp(tx.amount)} ditarik dari ${g?.name}`);
  };

  const tabs = [
    { id: "beranda", label: "Beranda", Icon: Home },
    { id: "buku", label: "Buku", Icon: BookOpen },
    { id: "target", label: "Celengan", Icon: Target },
  ];

  return (
    <div className="@container min-h-screen bg-background text-foreground">
      <div className="mx-auto flex min-h-screen max-w-[430px] flex-col pb-24">
        {/* Top bar */}
        <header className="flex items-center justify-between px-4 pt-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 overflow-hidden rounded-[12px]">
              <img src={icon} alt="Ikon Tabungan" className="h-full w-full scale-[1.22] object-cover" />
            </div>
            <span className="font-display text-xl font-extrabold tracking-tight">Tabungan</span>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Pengaturan">
                <MoreHorizontal />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuGroup>
                <DropdownMenuItem onSelect={() => { store.loadSample(); toast("Data contoh dimuat"); }}>Muat data contoh</DropdownMenuItem>
                <DropdownMenuItem variant="destructive" onSelect={() => { store.clearAll(); toast("Mulai dari nol. Semangat!"); }}>
                  <Trash2 /> Mulai dari nol
                </DropdownMenuItem>
              </DropdownMenuGroup>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        {/* Passbook cover */}
        {tab !== "buku" && (
          <section className="mx-4 mt-4 rounded-[20px] bg-sampul p-6 text-sampul-ink shadow-[0_18px_40px_-18px_oklch(0.36_0.091_333/0.7)]">
            <div className="flex items-start justify-between">
              <span className="text-sm font-semibold uppercase tracking-[0.2em] text-gilt">Buku Tabungan</span>
              <Glint />
            </div>
            <div key={bump} className={cn("mt-3 font-display text-[40px] leading-none font-extrabold tracking-tight", bump && "coin-drop")}>
              {rp(total)}
            </div>
            <div className="mt-4 flex items-center justify-between text-sm">
              <span className="opacity-80">Bulan ini <span className="font-semibold text-gilt">+{rp(monthIn)}</span></span>
              <span className="opacity-80">{totalTarget ? Math.min(100, Math.round((total / totalTarget) * 100)) : 0}% dari target</span>
            </div>
          </section>
        )}

        {tab === "beranda" && (
          <>
            <div className="mx-4 mt-4 grid grid-cols-2 gap-3">
              <Button size="lg" className="h-14 text-base font-bold" onClick={() => openTx("in")}>
                <Plus /> Setor
              </Button>
              <Button size="lg" variant="outline" className="h-14 text-base font-bold" onClick={() => openTx("out")}>
                <Minus /> Tarik
              </Button>
            </div>
            <div className="mt-8 flex items-baseline justify-between px-4">
              <h2 className="font-display text-xl font-extrabold">Celengan</h2>
              <button type="button" className="text-sm font-semibold text-primary" onClick={() => setGoalOpen(true)}>+ Baru</button>
            </div>
            <GoalList goals={data.goals} tx={data.tx} onDeposit={(id) => openTx("in", id)} compact />
            <div className="mt-8 flex items-baseline justify-between px-4">
              <h2 className="font-display text-xl font-extrabold">Mutasi terakhir</h2>
              <button type="button" className="text-sm font-semibold text-primary" onClick={() => setTab("buku")}>Buka buku</button>
            </div>
            <Passbook tx={data.tx} goals={data.goals} limit={4} printedId={printedId} />
          </>
        )}

        {tab === "buku" && (
          <>
            <div className="px-4 pt-6">
              <h1 className="font-display text-3xl font-extrabold tracking-tight">Buku tabungan</h1>
              <p className="mt-1 text-muted-foreground">Saldo {rp(total)}</p>
            </div>
            <Passbook tx={data.tx} goals={data.goals} printedId={printedId} filterable onRemove={(id) => { store.removeTx(id); toast("Mutasi dihapus"); }} />
          </>
        )}

        {tab === "target" && (
          <>
            <div className="mt-8 flex items-baseline justify-between px-4">
              <h2 className="font-display text-xl font-extrabold">Semua celengan</h2>
              <button type="button" className="text-sm font-semibold text-primary" onClick={() => setGoalOpen(true)}>+ Baru</button>
            </div>
            <GoalList
              goals={data.goals}
              tx={data.tx}
              onDeposit={(id) => openTx("in", id)}
              onWithdraw={(id) => openTx("out", id)}
              onRemove={(id) => { store.removeGoal(id); toast("Celengan dihapus"); }}
            />
          </>
        )}
      </div>

      {/* Bottom tabs */}
      <nav className="fixed inset-x-0 bottom-0 border-t bg-background/90 backdrop-blur">
        <div className="mx-auto grid max-w-[430px] grid-cols-3">
          {tabs.map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              aria-current={tab === id ? "page" : undefined}
              className={cn("flex flex-col items-center gap-1 py-3 text-sm font-semibold transition-colors", tab === id ? "text-primary" : "text-muted-foreground")}
            >
              <Icon className="h-5 w-5" strokeWidth={tab === id ? 2.6 : 2} />
              {label}
            </button>
          ))}
        </div>
      </nav>

      <TxDrawer open={txOpen} onOpenChange={setTxOpen} preset={txPreset} goals={data.goals} tx={data.tx} onSave={saveTx} />
      <GoalDrawer open={goalOpen} onOpenChange={setGoalOpen} onSave={(g) => { store.addGoal(g); toast.success(`Celengan "${g.name}" dibuat`); }} />
      <Toaster richColors position="top-center" />
    </div>
  );
}

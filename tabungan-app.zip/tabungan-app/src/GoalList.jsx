import { Plus, Minus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button.jsx";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog.jsx";
import { rp, goalBalance } from "./lib/store.js";

export default function GoalList({ goals, tx, onDeposit, onWithdraw, onRemove, compact }) {
  return (
    <div className="mx-4 mt-3 flex flex-col gap-3">
      {goals.map((g) => {
        const bal = goalBalance(tx, g.id);
        const pct = g.target ? Math.min(100, (bal / g.target) * 100) : 0;
        const done = bal >= g.target;
        return (
          <div key={g.id} className="rounded-[16px] border bg-card p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="truncate font-bold">{g.name}</div>
                <div className="mt-1 text-sm text-muted-foreground">
                  <span className="font-semibold tabular-nums text-foreground">{rp(bal)}</span> / {rp(g.target)}
                </div>
              </div>
              {compact ? (
                <Button size="icon" variant="secondary" aria-label={`Setor ke ${g.name}`} onClick={() => onDeposit(g.id)}>
                  <Plus />
                </Button>
              ) : (
                <span className={done ? "text-sm font-bold text-credit" : "text-sm font-bold text-primary"}>
                  {done ? "Tercapai!" : `${Math.round(pct)}%`}
                </span>
              )}
            </div>
            {/* coin-slot progress */}
            <div className="mt-3 h-3 overflow-hidden rounded-full bg-muted">
              <div
                className={done ? "h-full rounded-full bg-credit transition-[width] duration-700" : "h-full rounded-full bg-primary transition-[width] duration-700"}
                style={{ width: `${Math.max(pct, bal > 0 ? 4 : 0)}%` }}
              />
            </div>
            {!compact && (
              <div className="mt-4 flex gap-2">
                <Button size="sm" onClick={() => onDeposit(g.id)}><Plus /> Setor</Button>
                <Button size="sm" variant="outline" onClick={() => onWithdraw(g.id)} disabled={bal <= 0}><Minus /> Tarik</Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" variant="ghost" className="ml-auto" aria-label={`Hapus ${g.name}`}><Trash2 /></Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Hapus "{g.name}"?</AlertDialogTitle>
                      <AlertDialogDescription>Semua mutasinya ikut terhapus. Ini nggak bisa dibatalin.</AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Batal</AlertDialogCancel>
                      <AlertDialogAction variant="destructive" onClick={() => onRemove(g.id)}>Hapus</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            )}
          </div>
        );
      })}
      {goals.length === 0 && <p className="py-6 text-center text-muted-foreground">Belum ada celengan.</p>}
    </div>
  );
}

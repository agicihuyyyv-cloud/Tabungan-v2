# Tabungan

Aplikasi tabungan bergaya buku tabungan bank. Catat setoran & tarik, bikin celengan dengan target, dan lihat mutasi lengkap dengan saldo berjalan. Data disimpan di perangkat (localStorage), tanpa server.

## Fitur
- Saldo total + setoran bulan ini
- Celengan dengan target dan progress
- Setor / tarik dengan tombol nominal cepat (+10rb, +50rb, +100rb, +500rb)
- Buku mutasi dengan filter per celengan
- Bisa di-install ke HP (PWA)

## Jalankan di komputer
Butuh [Node.js](https://nodejs.org) versi 20 ke atas.

```bash
npm install
npm run dev
```

Buka alamat yang muncul (biasanya http://localhost:5173).

## Upload & online-kan lewat GitHub Pages
1. Bikin repo baru di GitHub, lalu upload semua isi folder ini (termasuk folder `.github`).
2. Di repo: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Push ke branch `main`. Tunggu workflow selesai di tab **Actions**.
4. App kamu online di `https://<username>.github.io/<nama-repo>/`.

## Jadiin APK
Paling gampang: setelah online di GitHub Pages, masukin link-nya ke [PWABuilder](https://www.pwabuilder.com) lalu pilih **Android** untuk download APK.

Alternatif (Capacitor, butuh Android Studio):
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init Tabungan com.tabungan.app --web-dir dist
npm run build
npx cap add android
npx cap open android
```
Lalu di Android Studio: **Build → Build APK(s)**.

## Struktur
- `src/App.jsx`: layar utama & navigasi
- `src/Passbook.jsx`: buku mutasi
- `src/GoalList.jsx`: daftar celengan
- `src/TxDrawer.jsx`, `src/GoalDrawer.jsx`: form setor/tarik & celengan baru
- `src/lib/store.js`: penyimpanan data
- `src/index.css`: tema warna & font
- `src/components/ui/`: komponen UI (shadcn/ui)
